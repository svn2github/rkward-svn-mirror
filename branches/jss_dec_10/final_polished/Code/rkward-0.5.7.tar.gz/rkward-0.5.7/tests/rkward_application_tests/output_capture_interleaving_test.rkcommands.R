local({
## Prepare
## Compute

				for (i in 1:20) {
					cat ("A")
					system ("echo B")
				}
			
## Print result
})
