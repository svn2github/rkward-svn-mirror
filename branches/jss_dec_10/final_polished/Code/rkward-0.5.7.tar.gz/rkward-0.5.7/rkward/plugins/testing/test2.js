function preprocess () {
	echo ("This is\n\tan embedded\ntest");
}

function calculate () {
	echo ('embbeded: x: ' + getValue ("x") + 'y: ' + getValue ("y") + 'box: ' + getValue ("box"));
}
