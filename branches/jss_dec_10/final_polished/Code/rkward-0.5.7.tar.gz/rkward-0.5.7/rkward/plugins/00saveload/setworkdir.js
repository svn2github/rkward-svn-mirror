function calculate () {
	echo ('setwd("' + getValue ("dir") + '")\n');
}

