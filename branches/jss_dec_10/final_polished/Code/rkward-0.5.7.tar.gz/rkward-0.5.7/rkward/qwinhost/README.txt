The files qwinhost.cpp and qwinhost.h in this directory are derivatives
of the files of the same names in the "Qt/MFC Migration Framework"
version 2.8 from Qt solutions.
http://www.qtsoftware.com/products/appdev/add-on-products/catalog/4/Windows/qtwinmigrate/

These files are
"Copyright (c) 2009 Nokia Corporation and/or its subsidiary(-ies)" as detailed
in the header portions of both files.

The applicable licences are contained in this directory in full form.

The files qwinhost.cpp.orig and qwinhost.h.orig are unmodified copies from the
"Qt/MFC Migration Framework" version 2.8. The files qwinhost.cpp and qwinhost.h
are modified for the needs of this project.

The original copyright holder(s) Nokia Corporation and/or its
subsidiary(-ies) are not to be held responsible for any malfunctioning. 

These files are used on windows, only.

Changes with respect to the qwinhost.cpp.orig and qwinhost.h.orig:

2009-06-05:
- Support for auto-destruction of client
- Notification when client is destroyed
- Notification when client window title changes
- Asynchronous handling of client focus changes
- Do not rely on GetParent() to return the right thing for captured windows
