/* Version number of package */
#define RKWARD_VERSION "0.5.7"
